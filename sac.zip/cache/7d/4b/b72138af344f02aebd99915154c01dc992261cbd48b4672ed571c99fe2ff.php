<?php

/* layout/site.html.twig */
class __TwigTemplate_7d4bb72138af344f02aebd99915154c01dc992261cbd48b4672ed571c99fe2ff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'css' => array($this, 'block_css'),
            'menu_principal' => array($this, 'block_menu_principal'),
            'conteudo' => array($this, 'block_conteudo'),
            'scripts' => array($this, 'block_scripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<html>
    <head>
        <title>";
        // line 3
        $this->displayBlock('titulo', $context, $blocks);
        echo "</title>
        <link rel=\"stylesheet\" type=\"text/css\" href=\"css/bootstrap-3.3.4-dist/css/bootstrap.min.css\" />
        <link rel=\"stylesheet\" type=\"text/css\" href=\"css/bootstrap-3.3.4-dist/css/bootstrap-theme.min.css\" />
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css\">        
        <link rel=\"stylesheet/less\" type=\"text/css\" href=\"css/estilo.less\" />
        ";
        // line 8
        $this->displayBlock('css', $context, $blocks);
        // line 9
        echo "    </head>
    <body>
        <div class=\"container-fluid effort site\">
            ";
        // line 12
        if ($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "isLogado", array(), "method")) {
            // line 13
            echo "                <div class=\"row barra-status\">                    
                    <div class=\"col-md-12\">
                        <ul class=\"nav navbar-nav navbar-right\">                    
                            <li class=\"dropdown\">
                                <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\"><i class=\"fa fa-user\"></i> ";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["user"]) ? $context["user"] : null), "getUsuario", array(), "method"), "getNome", array(), "method"), "html", null, true);
            echo " <span class=\"caret\"></span></a>
                                <ul class=\"dropdown-menu\" role=\"menu\">
                                    <li><a href=\"#\"><i class=\"fa fa-cogs\"></i> Configura&ccedil;&otilde;es</a></li>
                                    <li><a href=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('slim')->urlFor("logout"), "html", null, true);
            echo "\"><i class=\"fa fa-sign-out\"></i> Sair</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            ";
        } else {
            // line 27
            echo "                
            ";
        }
        // line 29
        echo "            <div class=\"row topo\">
                <div class=\"col-md-3 logotipo\">                    
                    <div class=\"row\">      
                        <div class=\"col-md-11 col-md-offset-1\">
                            <i class=\"fa fa-chevron-right claro\"></i>
                            <i class=\"fa fa-chevron-right escuro\"></i>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-11 col-md-offset-1\">
                            <h1>Effort</h1>
                        </div>
                    </div>
                </div>
                <div class=\"col-md-6 col-md-offset-1\">
                    ";
        // line 44
        if ($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "sucesso", array())) {
            // line 45
            echo "                        <div class=\"alert alert-success\" role=\"alert\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "sucesso", array()), "html", null, true);
            echo "</div>
                    ";
        }
        // line 47
        echo "                    ";
        if ($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "warning", array())) {
            // line 48
            echo "                        <div class=\"alert alert-warning\" role=\"alert\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "warning", array()), "html", null, true);
            echo "</div>
                    ";
        }
        // line 50
        echo "                    ";
        if ($this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "erro", array())) {
            // line 51
            echo "                        <div class=\"alert alert-danger\" role=\"alert\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["flash"]) ? $context["flash"] : null), "erro", array()), "html", null, true);
            echo "</div>
                    ";
        }
        // line 53
        echo "                </div>
            </div>
            <div class=\"row menu\">
                ";
        // line 56
        $this->displayBlock('menu_principal', $context, $blocks);
        // line 57
        echo "            </div>
            <div class=\"row conteudo\">
                <div class=\"col-md-12\">
                    ";
        // line 60
        $this->displayBlock('conteudo', $context, $blocks);
        // line 61
        echo "                </div>
            </div>
        </div>        
        <script type=\"text/javascript\" src=\"js/lib/jquery/jquery-1.11.3.min.js\"></script>
        <script type=\"text/javascript\" src=\"css/bootstrap-3.3.4-dist/js/bootstrap.min.js\"></script>
        <script type=\"text/javascript\" src=\"js/lib/less/lesscss.js\"></script>
        <script type=\"text/javascript\">
            jQuery(document).ready(function(){
                setTimeout(function(){
                    jQuery(\".alert\").fadeOut();
                }, 2500);
            });
        </script>
        ";
        // line 74
        $this->displayBlock('scripts', $context, $blocks);
        // line 75
        echo "    </body>
</html>";
    }

    // line 3
    public function block_titulo($context, array $blocks = array())
    {
        echo "Titulo";
    }

    // line 8
    public function block_css($context, array $blocks = array())
    {
    }

    // line 56
    public function block_menu_principal($context, array $blocks = array())
    {
    }

    // line 60
    public function block_conteudo($context, array $blocks = array())
    {
    }

    // line 74
    public function block_scripts($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout/site.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 74,  166 => 60,  161 => 56,  156 => 8,  150 => 3,  145 => 75,  143 => 74,  128 => 61,  126 => 60,  121 => 57,  119 => 56,  114 => 53,  108 => 51,  105 => 50,  99 => 48,  96 => 47,  90 => 45,  88 => 44,  71 => 29,  67 => 27,  57 => 20,  51 => 17,  45 => 13,  43 => 12,  38 => 9,  36 => 8,  28 => 3,  24 => 1,);
    }
}
