<?php

/* home/index.html.twig */
class __TwigTemplate_7766bf922124097218b8a182d56592efb35fd98c2f5ed4ee3564ec3f7b1daab1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout/site.html.twig", "home/index.html.twig", 1);
        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'conteudo' => array($this, 'block_conteudo'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout/site.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_titulo($context, array $blocks = array())
    {
        echo "Titulo do home/index";
    }

    // line 4
    public function block_conteudo($context, array $blocks = array())
    {
        // line 5
        echo "    <div class=\"row\">
        ";
        // line 6
        if ( !$this->getAttribute((isset($context["user"]) ? $context["user"] : null), "isLogado", array(), "method")) {
            // line 7
            echo "        <div class=\"col-md-4 col-md-offset-4\">
            <form class=\"form form-horizontal form-login\" method=\"post\" action=\"";
            // line 8
            echo twig_escape_filter($this->env, (isset($context["urlAutenticar"]) ? $context["urlAutenticar"] : null), "html", null, true);
            echo "\">        
                <div class=\"form-group\">
                    <label class=\"col-sm-2 control-label\">Login:</label>
                    <div class=\"col-sm-10\">
                        <input type=\"text\" name=\"login\" class=\"form-control\" id=\"login\" value=\"\" />
                    </div>
                </div>
                <div class=\"form-group\">
                    <label class=\"col-sm-2 control-label\">Senha:</label>
                    <div class=\"col-sm-10\">
                        <input type=\"password\" name=\"senha\" class=\"form-control\" id=\"senha\" value=\"\" />
                    </div>
                </div>
                <div class=\"form-group\">
                    <div class=\"col-sm-offset-2 col-sm-10\">
                        <button type=\"submit\" class=\"btn btn-default\">Entrar</button>
                    </div>
                </div>
            </form>
        </div>
        ";
        } else {
            // line 29
            echo "            <ul class=\"nav nav-tabs\">
                <li role=\"presentation\" class=\"active\"><a href=\"#\">Consultar Atendimento</a></li>
                <li role=\"presentation\"><a href=\"#\">Criar Atendimento</a></li>
                <li role=\"presentation\"><a href=\"#\">Outra Op&ccedil;&atilde;o</a></li>
            </ul>
        ";
        }
        // line 35
        echo "    </div>
";
    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 35,  70 => 29,  46 => 8,  43 => 7,  41 => 6,  38 => 5,  35 => 4,  29 => 2,  11 => 1,);
    }
}
