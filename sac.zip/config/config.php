<?php

class Config {
    /**
     * Configurações do banco de dados
     * 
     * @var array
     */
    public static $db = array(
        'dbname'        => 'sac',
        'dbuser'        => 'root',
        'dbpassword'    => '',
        'host'          => 'localhost',
        'port'          => '3306'
    );
}

